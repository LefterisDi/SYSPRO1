#ifndef __BFS_H__
#define __BFS_H__

#include "../bitcoinTreeList/bitcoinTreeList.h"
#include "../bitcoinInnerTreeNodeList/bitcoinInnerTreeNodeList.h"

int Bfs(Tree_Node* , char* , InnerTreeListNode**); 

#endif